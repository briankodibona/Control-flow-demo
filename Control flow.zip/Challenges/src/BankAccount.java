public class BankAccount {
    private String accountNumber = "0";
    private double accountBalance = 0.0;
    private String customerName;
    private String customerEmail;
    private String customerPhone;

    public BankAccount(){
        this("6789", 10000, "Bob", "Bob@Gmail.com" , "082 723456778");
        System.out.println("Empty Constructor called");

    }

    public BankAccount(String customerName, String customerEmail, String customerPhone) {
        this("9999", 1000.55, customerName,customerEmail,customerPhone);
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.customerPhone = customerPhone;
    }

    public BankAccount(String accountNumber, double accountBalance, String customerName, String customerEmail, String customerPhone){
        System.out.println("Account constructor with parameters called");
        this.accountNumber = accountNumber;
        this.accountBalance = accountBalance;
        this.customerName = customerName;
        this.customerEmail = customerEmail;
        this.customerPhone = customerPhone;
    }

    public void depositFunds(double amount){
        accountBalance += amount;
        System.out.println("Amount deposited = " + amount + " new balance amount is =  " + accountBalance);
    }

    public void withdrawFunds(double amount){
        if (amount < this.accountBalance) {
            accountBalance -= amount;
            System.out.println("Amount withdrawn = " + amount + " new balance is = " + amount);
        }
        System.out.println("Insufficient funds! You only have " + accountBalance );
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public double getAccountBalance() {
        return accountBalance;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public void setAccountBalance(double accountBalance) {
        this.accountBalance = accountBalance;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone;
    }



    public void getAccountInformation(){
        System.out.println("Account Number = " + this.accountNumber);
        System.out.println("Account balance = " + this.accountBalance);
    }
}
