public class ClassChallenge {
    public static void main(String[] args) {
     BankAccount bobsAccount = new BankAccount();
     BankAccount johnAccount = new BankAccount("John", "John@gmail.com", " 082345678");
     System.out.println("Account number: " + johnAccount.getAccountNumber() +
             "   Account balance : " + johnAccount.getAccountBalance());

        //   BankAccount bobsAccount = new BankAccount("1234", 10000, "Bob Brown", "Bob@brown.com", "082 123 4567");
       System.out.println(bobsAccount.getAccountBalance());
       System.out.println(bobsAccount.getAccountNumber());


        /* bobsAccount.setCustomerEmail("John@gmail.com");
        bobsAccount.setCustomerName("John");
        bobsAccount.setCustomerPhone("0123456789");
        bobsAccount.setAccountNumber("12345678");
        bobsAccount.setAccountBalance(123456);*/
        //getAccountInformation();
        bobsAccount.withdrawFunds(1234567);
        bobsAccount.depositFunds(1000);


    }
}
