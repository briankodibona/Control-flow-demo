public class theWhileLoopChallenge {
    public static void main(String[] args) {
        int test = 51;
        int counterEven = 0;
        int counterOdd = 0;
        int i = 5;
        while(i >= 5 && i <= 20 && counterEven < 5){
            i++;
            if(!isEvenNumber(i)){
                counterOdd++;
                continue;
            }

            if (isEvenNumber(i)){
            System.out.println(i);
            counterEven += 1;
            }
        }
            System.out.println("Total numbers are :(first) " + counterEven);
        System.out.println("Total numbers are :(firstOdd) " + counterOdd);

        counterEven = 0;
        counterOdd = 0;
        int number = 4;
        int finishNumber = 20;

        while (number <= finishNumber && counterEven < 5){
            number++;
            if (!isEvenNumber(number)) {
               counterOdd ++;
                continue;
            }
            System.out.println("Even number " + number);
            counterEven +=1;
            if (counterEven == 5){
                break;
            }
        }
        System.out.println("Total numbers are :(Second) " + counterEven);
        System.out.println("Total numbers are :(SecondOdd) " + counterOdd);
    }

    public static boolean isEvenNumber(int number){
        if (number % 2 != 0){
            return false;
        }
        return true;
    }
}
