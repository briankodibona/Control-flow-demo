public class digitSumChallenge {
    public static void main(String[] args) {
        System.out.println(sumDigits(1567));
        System.out.println(sumDigits(135567));
        System.out.println(sumDigits(1));
        System.out.println(sumDigits(768541567));
        System.out.println(sumDigits(-1567));
    }

    public static int sumDigits(int inputNumber) {
        int number = inputNumber;
        int sum = 0;
        int counter = 0;

        if (inputNumber < 0){
            return -1;
        }

        if (number > 0 & number < 10){
            return number;
        }

        for (int i = 1; i < 100; i++) {

            int parsed = number % 10;
            sum = +parsed;
            number = number / 10;

            counter += sum;

            if (number > 0 & number < 10){
                counter += number;
                return counter;
            }

        }
        sum = 0;
        while (inputNumber > 9){
            sum += (inputNumber % 10);
            inputNumber = inputNumber /10;
        }
        sum += number;
        System.out.println(sum);
        return sum;

    }

}
