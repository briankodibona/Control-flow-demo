public class ComplexNumber {
    private double real;
    private double imaginary;

    public ComplexNumber(double real, double imaginary) {
        this.real = real;
        this.imaginary = imaginary;
    }

    public double getReal() {
        return real;
    }

    public double getImaginary() {
        return imaginary;
    }

    public void add(double realInput,double imaginaryInput){
            this.real = real + realInput;
            this.imaginary = imaginary + imaginaryInput;
    }

    public void add(ComplexNumber input){
        real = real + input.real;
        imaginary = imaginary + input.imaginary;

    }

    public void subtract(double realInput, double imaginaryInput){
        this.real = real - realInput;
        this.imaginary = imaginary - imaginaryInput;
    }

    public void subtract (ComplexNumber input){
        this.real = real - input.real;
        this.imaginary = imaginary - input.imaginary;
    }
}
